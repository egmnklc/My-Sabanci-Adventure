#ifndef _PLAYERTEMPLATE_H
#define _PLAYERTEMPLATE_H

template <class myType>
class Player
{
    private:
        int id;
        static int next_id;
		Board<myType> & private_board;

    public:
		Player (Board<myType> & board_name) : private_board(board_name) 
		{
			id = next_id;
			next_id++;
		}
		bool updateCell (int rIndex, int cIndex, myType value);
		void updateMyCells (myType val);
		bool unclaimOwnership (int r, int c);
		void unclaimOwnerships ();
		int returnId();

};

#include "Player_cpp.cpp"

#endif