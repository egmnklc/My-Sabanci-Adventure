#include <iostream>
#include <string>

using namespace std;

template <class myType>
int Player<myType>::next_id = 1;

template <class myType>
bool Player<myType>::unclaimOwnership(int r, int c)
{
	return private_board.unclaimSpecificCell(r, c, id);
}

template <class myType>
void Player<myType>::unclaimOwnerships()
{
	private_board.unclaimAllOwnerships(id);
}

template <class myType>
void Player<myType>::updateMyCells(myType val)
{
	private_board.updateAllMyCells(val, id);
}

template <class myType>
int Player<myType>::returnId()
{
	return id;
}

template <class myType>
bool Player<myType>::updateCell(int rindex, int cindex, myType val)
{
	return private_board.updateSpecificCell(rindex, cindex, val, id);
}