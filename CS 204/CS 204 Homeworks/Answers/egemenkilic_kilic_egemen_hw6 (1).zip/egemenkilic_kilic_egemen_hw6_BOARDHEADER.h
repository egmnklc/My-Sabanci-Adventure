#ifndef _BOARDTEMPLATE_H
#define _BOARDTEMPLATE_H

template <class myType>
struct cell 
{
    int current_owner;
    myType value;

    cell () : current_owner(0)
    {}

    cell (const int & ownerID, myType val)
    : current_owner (ownerID), value (val)
    { }

};

template <class myType>
class Board
{
    private:
        int number_of_rows;
        int number_of_columns;
        cell<myType> ** matrix;

    public:
        Board<myType> (int rowNumber, int columnNumber)
        {
            number_of_rows = rowNumber;
            number_of_columns = columnNumber;

            matrix = new cell<myType> * [number_of_rows];

            for (int i = 0; i < number_of_rows; i++)
            {
                matrix[i] = new cell<myType>[number_of_columns];
            }

        }        
        Board(const Board & copy); // Deep copy constructor
		cell<myType> ** createClone() const;
        void updateBoardCells (int playerID, myType some_value);
		bool updateSpecificCell (int rowIndex, int columnIndex, myType cellValue, int player_ID);
		void updateAllMyCells (myType val, int player_ID);
		bool unclaimSpecificCell(int rowIndex, int columnIndex, int player_ID);
		void unclaimAllOwnerships (int player_ID);
		void displayBoard();
        int getPlayerCellsCount (int playerID);
        int knowTheOwner(int rowIndex, int columnIndex);
         //~Board(); // Destructor
};

#include "Board_cpp.cpp"

#endif