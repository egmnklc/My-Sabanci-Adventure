#include <iostream>
using namespace std;

template <class myType>
void Board<myType>::unclaimAllOwnerships(int player_ID)
{
	for (int i = 0; i < number_of_rows; i++)
	{
		for (int j = 0; j < number_of_columns; j++)
		{
			if (matrix[i][j].current_owner == player_ID)
			{
				matrix[i][j].current_owner = 0;
			}
		}
    }
}

template <class myType>
bool Board<myType>::unclaimSpecificCell(int r, int c, int player_ID)
{
	if (matrix[r][c].current_owner == player_ID)
	{
		matrix[r][c].current_owner = 0;
		return true;
	}

	return false;
}

template <class myType>
void Board<myType>::updateAllMyCells (myType val, int player_ID)
{
	for (int i = 0; i < number_of_rows; i++)
	{
		for (int j = 0; j < number_of_columns; j++)
		{
			if (matrix[i][j].current_owner == player_ID)
			{
				matrix[i][j].value = val;
			}
		}
    }
}

template <class myType>
bool Board<myType>::updateSpecificCell(int r, int c, myType cellValue, int p_id)
{
	if ( (matrix[r][c].current_owner == 0) || (matrix[r][c].current_owner == p_id) )
	{
		matrix[r][c].current_owner = p_id;
		matrix[r][c].value = cellValue;
		return true;
	}

	return false;
}	

template <class myType>
cell<myType> ** Board<myType>::createClone() const{
	cell<myType>** cloned_matrix;
	cloned_matrix = new cell<myType> * [number_of_rows];

	for (int i = 0; i < number_of_rows; i++)
	{
		cloned_matrix[i] =  new cell<myType> [number_of_columns];
		cloned_matrix[i] = matrix[i];
	}

	return cloned_matrix;
}

template <class myType>
Board<myType>::Board(const Board & copy) 
{
	matrix = copy.createClone();

	number_of_rows = copy.number_of_rows;
	number_of_columns = copy.number_of_columns;
}

template <class myType>
int Board<myType>::knowTheOwner(int rowIndex, int columnIndex)
{
	return matrix[rowIndex][columnIndex].current_owner;
}

template <class myType>
int Board<myType>::getPlayerCellsCount(int playerID)
{
	int counter = 0;
	for (int i = 0; i < number_of_rows; i++)
	{
		for (int j = 0; j < number_of_columns; j++)
		{
			if (matrix[i][j].current_owner == playerID)
			{
				counter++;
			}
		}
    }

	return counter;
}

template <class myType>
void Board<myType>::updateBoardCells(int playerID, myType some_value)
{
    for (int i = 0; i < number_of_rows; i++)
	{
		for (int j = 0; j < number_of_columns; j++)
		{
			if ( (matrix[i][j].current_owner == 0) || (matrix[i][j].current_owner == playerID))
			{
				matrix[i][j].current_owner = playerID;
				matrix[i][j].value = some_value;
			}
		}
    }
}

template <class myType>
void Board<myType>::displayBoard()
{
	cout << "Displaying the board: Each cell is shown as tuple (CURRENT OWNER ID, VALUE):" << endl;

	for (int k = 0; k < number_of_columns; k++)
	{
		cout << "       " << k;
	}
	cout << endl;


	for (int i = 0; i < number_of_rows; i++)
	{
		cout << i << "    ";
		for (int j = 0; j < number_of_columns; j++)
		{
			cout << "  (" << matrix[i][j].current_owner << ", " << matrix[i][j].value << ")";
		}
		cout << endl;
	}
}