#include <iostream>

using namespace std;

int main()
    {
    function((int)10.1, {1,2,3});
    {
        cout << "hello";
    }
    return 0;
}

