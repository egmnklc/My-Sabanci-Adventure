int main(){
    x(10, {20};
    y(5)}
}