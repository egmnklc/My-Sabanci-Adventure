int main(){
    x(10, {20});
    y(5);
    (1+5+(11));
}
}
void who(){
    cout << "hello once more";
}