#include <iostream>
#include <iomanip>
#include <thread>
#include <mutex>
#include <random>
#include <time.h>
#include <chrono>
#include "egemenkilic_kilic_egemen_HW7_PrintQueue.h"

using namespace std;

mutex cout_mutex, queue_mutex;
HW7PrintQueue printer_queue;
int job_id = 1, max_jobs = 0;

//* Print system time
void system_time()
{
    time_t tt = chrono::system_clock::to_time_t (chrono::system_clock::now());  //gets the current time
	struct tm *ptm = new struct tm;  
	localtime_s(ptm, &tt);  
	cout  << put_time(ptm,"%X") << endl;  
}

//* Generate random range for 2 ints.
int random_range(const int & min, const int & max) 
{
    static mt19937 generator(time(0));
    uniform_int_distribution<int> distribution(min, max);
    return distribution(generator);
}

//* Dequeue jobs, related to printing process.
void dequeue_job ()
{
	while (printer_queue.getCurrentSize() != 0)
	{
		if ( !printer_queue.isEmpty() )
		{
			queue_mutex.lock();
			int dequeued_id, page_no;
			printer_queue.dequeue(dequeued_id, page_no);
			queue_mutex.unlock();

			cout_mutex.lock();
			cout << "The printer started to print the job with ID: " << dequeued_id << ", number of pages: " << page_no << " (queue size is: " << printer_queue.getCurrentSize() << ") ";
			system_time();
			cout_mutex.unlock();

			this_thread::sleep_for(chrono::seconds(page_no)); 

			cout_mutex.lock();
			cout << "The printer finished printing the job with ID: " << dequeued_id << ", number of pages: " << page_no << " "; system_time();
			cout_mutex.unlock();
		}
	}	
}
//* Send job to printer, thread function.
void send_job(int user_id, int min_pages, int max_pages, int min_seconds, int max_seconds)
{
	int page_number = random_range(min_pages, max_pages);

	while (max_jobs != 0)
	{
		if (job_id == 0) 
		{
			this_thread::sleep_for(chrono::seconds(random_range(min_seconds, max_seconds)));
		}

		//* Lock mutexes to prevent context shifting at unwanted times.
		queue_mutex.lock();
		max_jobs--;
		printer_queue.enqueue(job_id, page_number);
		queue_mutex.unlock();

		cout_mutex.lock();
		cout << "User " << user_id << " sent new print job with ID " << job_id << " sent to the printer queue, number of pages: " << page_number
			<< "( print queue size: " << printer_queue.getCurrentSize() << ") "; system_time();
		job_id++;
		cout_mutex.unlock();

		this_thread::sleep_for(chrono::seconds(random_range(min_seconds, max_seconds)));

	}
}


int main()
{
    int min_seconds = 0, max_seconds = 0, min_pages = 0, max_pages = 0;
	//* User inputs begin
    cout << "Please enter the max number of print jobs: "; cin >> max_jobs;
    cout << "Please enter the min and max values for the waiting time period (in seconds) after creating a print job: " << endl;
    cout << "Min: "; cin >> min_seconds;
    cout << "Max: "; cin >> max_seconds; 

	cout << "Please enter the min and max values for the number of pages in a print job:" << endl;
	cout << "Min number of pages: "; cin >> min_pages;
	cout << "Max number of pages: "; cin >> max_pages;

    cout << "Simulation starts: "; system_time();
	//* User inputs end
	//* Spawn threads for 3 users and for the printer
    thread user1_thread(&send_job, 1, min_pages, max_pages, min_seconds, max_seconds);
    thread user2_thread(&send_job, 2, min_pages, max_pages, min_seconds, max_seconds);
    thread user3_thread(&send_job, 3, min_pages, max_pages, min_seconds, max_seconds);
	thread printer_thread(&dequeue_job);

	//* Join threads after all thread processes begin.
	user1_thread.join();
	user2_thread.join();
	user3_thread.join();
	printer_thread.join();

	cout << "End of the simulation ends "; system_time();

	system("pause");
    return 0;
}