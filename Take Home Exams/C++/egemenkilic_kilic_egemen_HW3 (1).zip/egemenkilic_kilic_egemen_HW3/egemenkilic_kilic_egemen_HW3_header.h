#include <iostream>
#include <string>

using namespace std;

struct node
{
    char data;
    node *right;
    node *down;

    node() // Default construtor
    {
        data = '-'; 
        right = NULL; 
        down = NULL;
    }

    node (char data, node *right, node*down) : data (data), right(right), down(down) {}
};
// constructoda headi null'a esitle, head null mu degil mi.
class TwoDLinkedList
{
    private:
        node *head;
    public:
		TwoDLinkedList();
        void insert_back(node ** head, char back_char);
        void add_row_sorted(string line);
        void displayFullMatrix();
        void displayFullMatrixReversed();
        void display_rows_starting_with(char ch);
        void display_cols_starting_with(char ch);
        int delete_rows_starting_with(char del_Char);
        int delete_cols_starting_with(char del_Char);
        void clear();
};


