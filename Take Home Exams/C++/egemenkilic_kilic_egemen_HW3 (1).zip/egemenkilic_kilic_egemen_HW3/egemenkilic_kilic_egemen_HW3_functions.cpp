# include <iostream>
# include "playground.h"

using namespace std;

TwoDLinkedList::TwoDLinkedList()
{
	head = NULL;
}

void TwoDLinkedList::add_row_sorted(string line)
{
    int counter = line.length();

    node *current = new node();
    node *result;

    if (head == NULL)
    {
        head = new node('#', NULL, NULL);
        while (counter != -1)
        {
            if (line[counter] != '\0')
            {
                result = new node(line[counter], current, NULL);
                current = result;
                counter--;
            }
            else
            {
                counter--;
            }
            
        }
        head->right = current;
        // Set head's right equal to the first word in the text file;
       
        node *head_clone = head->right;
        // cout << endl << "Value of head->right is: ";

        while (head_clone != NULL)
        {
            if (head_clone->data != '-')
            {

                cout << head_clone->data;
                head_clone = head_clone->right;
            }
            else
            {
                head_clone = head_clone->right;
            }
        }
        cout << endl;
        // Print head's next value to the screen.
    }
    else
    {
        node *current_copy = current;
        node *result_copy;
        // cout << "Line is: " << line << endl;
        node * ch = head->right;
        counter = line.length();

        while (counter != -1)
        {
            if (line[counter] != '\0')
            {
                result_copy = new node(line[counter], current_copy, NULL);
                current_copy = result_copy;
                counter--;
            }
            else
            {
                counter--;
            }
        }

        int ctr = line.length();
        while (ch->down != NULL)
        {
            ch = ch->down;
        }
        // cout << "Ch data: "<<ch->data;
        cout << endl;

        if (line[0] >= ch->data)
        {
            cout << line << " | " << ch->data  << " line should be down." << endl;
            
            node *result_down;
            node *current_down = new node();

            int up_counter = line.length();

            while (up_counter != -1)
            {
                if (line[up_counter] != '\0')
                {
                    result_down = new node(line[up_counter], current_down, NULL);
                    current_down = result_down;
                    up_counter--;
                }
                else
                {
                    up_counter--;
                }
            }

            int down_down = line.length();
            
            
            // Dummy part begin.
            // cout << "Value of current_down_copy: ";
            node *current_down_copy = current_down;
            node *last_row = head->right;
            int ctr = line.length();

            while (last_row->down != NULL)
            {
                last_row = last_row->down;
            }
            
            // cout << "last_row->down is null: " << (last_row->down == NULL) << endl;
            // cout << current_down_copy->data << endl;

            while (ctr != -1)
            {
                last_row->down = current_down_copy;
                last_row = last_row->right;
                current_down_copy = current_down_copy->right;
                ctr--;
            }

            
            while (current_down_copy != NULL)
            {
                cout << current_down_copy->data;
                current_down_copy = current_down_copy->right;
            }
            cout << endl;
            // Dummy part ends
        }
        else
        {

            cout << line << " | " << ch->data << " line should be up." << endl;
            node *result_up;
            node *current_up = new node();

            int up_counter = line.length();

            while (up_counter != -1)
            {
                if (line[up_counter] != '\0')
                {
                    result_up = new node(line[up_counter], current_up, NULL);
                    current_up = result_up;
                    up_counter--;
                }
                else
                {
                    up_counter--;
                }
            }
            // Dummy part begin.
            cout << "Moving ";

            node *current_up_copy = current_up;

            while (current_up_copy != NULL)
            {
                cout << current_up_copy->data;
                current_up_copy = current_up_copy->right;
            }

            node *move_up = current_up_copy;
            node *previous_node = head->right;
            node *after_node = head->right;

            while (previous_node->data >= ch->data)
            {
                previous_node = previous_node->down;
            }

            while (after_node->data != ch->data)
            {
                after_node = after_node->down;    
            }
            
            cout << " to up."<< endl;
            previous_node->down = current_up;
            current_up->down = after_node;
            ch->data = current_up->data;
            cout << previous_node->data << " previous_node->data " << current_up->data << endl;
            // Dummy part ends.
            
        }


    }
}

void TwoDLinkedList::displayFullMatrix()
{
    int colum_counter = 0;
    node *dummy_to_count_column = head->right;

    while(dummy_to_count_column != NULL)
    {
        if(dummy_to_count_column->data != '-')
        {
            colum_counter++;
            dummy_to_count_column = dummy_to_count_column->right;
        }
        else
        {
            dummy_to_count_column = dummy_to_count_column->right;
        }
    }

    int row_counter = 0;
    node *dummy_to_count_row = head->right;
    while (dummy_to_count_row != NULL)
    {
        row_counter ++;
        dummy_to_count_row = dummy_to_count_row->down;
    }

    // cout << "Rows: " << row_counter << " | " << "Columns: " << colum_counter << endl;

    node *print_row = head->right;
    node *dum = head->right;
    int colum_counter_copy = colum_counter;

    for (int i = row_counter; i != 0; i--)
    {
        while (colum_counter_copy != 0)
        {
            cout << print_row->data;
            print_row = print_row->right;
            colum_counter_copy--;
        }
        colum_counter_copy = colum_counter;
        print_row = dum->down;
        dum = print_row;
        cout << endl;
    }
}

void TwoDLinkedList::displayFullMatrixReversed()
{
    node *last = head->right;

    node *before_last;

    while (last->down != NULL)
    {
        cout << last->data;
        last = last->down;
    }
}

void TwoDLinkedList::display_rows_starting_with(char ch)
{
    node *printer = head->right;
    node *printerNode = head->right;
    int printerCount = 0;

    while (printerNode!=NULL)
    {
        printerCount++;
        printerNode = printerNode->down;
    }

    while (printerCount != 0)
    {
        while (printer != NULL)
        {
            if (printer->data == ch)
            {
                node * dum = printer;
                while (dum->data != '-')
                {
                    cout << dum->data;
                    dum = dum->right;
                }
                cout << endl;
                printer = printer->down;
            }
            else
            {
                printer = printer->down;
            }
        }
        printerCount--;
    }

}

void TwoDLinkedList::display_cols_starting_with(char ch)
{
    node *column_printer = head->right;

    while (column_printer->data != ch)
    {
        column_printer = column_printer->right;
    }

    while (column_printer != NULL)
    {
        cout << column_printer->data << endl;
        column_printer = column_printer->down;
    }
}

int TwoDLinkedList::delete_rows_starting_with (char del_Char)
{
    cout << "delete_rows_starting_with" << endl;
	return 0;
}

int TwoDLinkedList::delete_cols_starting_with(char del_Char)
{  
    node* distinct = head->right;
    int ctr = 0;
    while (head != NULL && head->data == del_Char)
    {
        head = head->right;
        ctr++;
    }
    
    while (distinct->right != NULL)
    {
        if (distinct->right->data == del_Char)
        {
            distinct->right = distinct->right->right;
            ctr++;
        }
        else
        {
            distinct = distinct->right;
        }
    }

    return ctr;
}

void TwoDLinkedList::clear()
{
    node *row = head->down; 
    node *column = head->right;
}