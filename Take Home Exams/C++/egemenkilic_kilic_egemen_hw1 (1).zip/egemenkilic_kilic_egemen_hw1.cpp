#include <iostream>
#include <fstream>
#include <string>
#include <vector>

/*
    TODO: Fix the out of range problem for word6.txt, word4.txt - FIXED
    ! Fix the bug for word6.txt - FIXED
*/

using namespace std;

struct cell
{
    char letter;
    char color;
};

// Print the game board

void printBoard(const string WORD, vector < vector <cell> > GAME_BOARD, const unsigned int lives)
{
    for (int a = 0; a < lives; a++)
    {
        for (int b = 0; b < WORD.length(); b++)
        {
            cout << "|| " << GAME_BOARD.at(a).at(b).letter <<
            " , " <<
            GAME_BOARD.at(a).at(b).color << " ";
        }
        cout << "||"<<endl;
    }
}

// Set letter and color positions and color char

bool charExists(const string GUESS, const string WORD, vector< vector < cell > > & GAME_BOARD, int row_counter, int lives)
{
    for (int column = 0; column < WORD.length(); column++) 
    {
        // ROW
        if (WORD.find(GUESS.at(column)) == -1)
        {
            GAME_BOARD.at(row_counter).at(column).color = 'B'; 
            GAME_BOARD.at(row_counter).at(column).letter = GUESS.at(column);
        }

        else if ( (WORD.find(GUESS.at(column)) != -1) && WORD.at(column) == GUESS.at(column))
        {
            GAME_BOARD.at(row_counter).at(column).color = 'G';
            GAME_BOARD.at(row_counter).at(column).letter = GUESS.at(column);
        }

        else if ( (WORD.find(GUESS.at(column)) != -1) && WORD.at(column) != GUESS.at(column))
        {
            GAME_BOARD.at(row_counter).at(column).color = 'Y';
            GAME_BOARD.at(row_counter).at(column).letter = GUESS.at(column);
        }

    }
    return true;
}

// Check if guess has duplicate characers
bool hasDuplicateChars(string guess)
{
    string chars = guess;
    for (int j = 0; j < guess.length(); j++)
    {
        if (guess.find(chars.at(j)) != guess.rfind(chars.at(j)))
        {
            return true;
        }
    }
    return false;
}

bool hasSpecial(string guess)
{
    for (int b = 0; b < guess.length(); b++)
    {
        if (isalpha(guess.at(b)) == 0)
        {
            return true;
        }
    }
    return false;
}

// Check if guess has numeric characters
bool hasNumericChar(string guess)
{
    for (int i = 0; i < guess.length(); i++)
    {
        if (isdigit(guess.at(i)))
        {
            return true;
        }
    }
    return false;
}

// Check if guess is used before
bool wordUsedBefore(const string guess, string guessedWords)
{

    if (guessedWords.find(guess) != guessedWords.rfind(guess) && guessedWords.find(guess) != -1)
    {
        return true;
    }

    return false;
}

// Check if guess has uppercase characters
bool hasUppercaseChar(string guess)
{
    for (int a = 0; a < guess.length(); a++)
    {
        if (toupper(guess.at(a)) == guess.at(a))
        {
            return true;
        }
    }
    return false;
}

// Check if chars in guess and words are valid and is/are in a green char
bool checkChars(string greenChars, string guess, string word)
{
    int counter = 0;

    for (int i = 0; i < greenChars.length(); i++)
    {
        for (int j = 0; j < guess.length(); j++)
        {            
            // cout << "Greenchars: " << greenChars << " Letter: " << greenChars.at(i) << " Guess: " << guess << " Word: " << word << endl;
            // cout << "Char is: " << greenChars.at(i) << endl;

            if (greenChars.at(i) == guess.at(j))
            {
                if (guess.at(j) == word.find(guess.at(j)))
                {
                    // cout << 135 << endl;
                    counter++;
                }
                else if (guess.find(greenChars.at(i)) == word.find(greenChars.at(i)))
                {
                    // cout << 139 << endl;
                    counter++;
                }
                else if (word.find(greenChars.at(i)) != -1)
                {
                    if (word.find(greenChars.at(i)) == guess.find(greenChars.at(i)))
                    {
                        counter++;
                        // cout << 148 << endl;
                    }
                }
            }
            if (counter == greenChars.length())
            {
                return true;
            }
        }
    }
    return false;
}

int main()
{
    ifstream MAIN_FILE;
    string inputName = "", err ="", greenChars = "";

    cell Cell;

    bool greenExists = false;

    cout << "Welcome to SWordle!" << endl << "Please enter the filename: "; cin >> inputName;
    

    MAIN_FILE.open(inputName.c_str());
        
    while(MAIN_FILE.fail())
    {
        cout << "Couldn't find the file!" << endl << "Please enter the filename: "; cin >> inputName; 
        MAIN_FILE.clear();
        MAIN_FILE >> err;
        MAIN_FILE.open(inputName.c_str());
    }

    int lives = 0;  
    bool continueGame = true;
    string word = "", guess = "", guessedWords = "";

    while (MAIN_FILE >> lives >> word) 
    {
        vector<vector< cell >> game_Board(lives, vector< cell > (word.length()) );
        
        int copyLives = lives;
        int row_counter = 0;

        for (int i = 0; i < lives; i++)
        {
            for (int j = 0; j < word.length(); j++)
            {
                game_Board.at(i).at(j).letter = '-';
                game_Board.at(i).at(j).color = '-';
            }
        }

        /* 
            ! DEBUG ONLY
            cout << lives << " " << word << endl; 
         */ 
        
        
        cout << "The word you will guess has " << word.length() << " letters and you have " << lives << " attempts." << endl;
        while (continueGame)
        {
            if (copyLives > 0)
            {
                cout << "What's your guess? "; cin >> guess;
                
                if (guess.length() > word.length())
                {
                    cout << "The word is too long!" << endl;
                }
                else if (guess.length() < word.length())
                {
                    cout << "The word is too short!" << endl;
                }
                else if ( (guess.length() == word.length() && hasNumericChar(guess) == true && hasUppercaseChar(guess) == true) )
                {
                    cout << "Your input has illegal letters!" << endl;
                }
                else if ( hasNumericChar(guess) || hasSpecial(guess) != 0 || hasUppercaseChar(guess) == true)
                {
                    cout << "Your input has illegal letters!" << endl;
                }
                else
                {
                    // cout << "Has special: " << (hasSpecial(guess)) << " " << guess  << " " << isalpha('@') << endl;

                    if ( hasDuplicateChars(guess) )
                    {
                        cout << "Your input has a duplicate letter!" << endl;
                    }
                    
                    else if ( hasDuplicateChars(guess) == false && hasNumericChar(guess) == false && hasUppercaseChar(guess) == false)
                    {
                        // If input is valid: 
                        guessedWords += guess + " ";

                        // cout << "Word used before?: " << wordUsedBefore(guess, guessedWords) << " " 
                        // << guessedWords << endl;
                        if (wordUsedBefore(guess, guessedWords) != true)
                        {
                            if (copyLives == 0)
                            {
                                cout << "You lose!"<< endl;
                                continueGame = false;
                            }
                            else if (copyLives > 0 && guess == word)
                            {
                                charExists(guess, word, game_Board, row_counter, lives);
                                printBoard(word, game_Board, lives);
                                cout << "You win!" << endl;

                                
                                continueGame = false;
                            }
                            else
                            {
                               /*
                                   *Check guess' characters are in word.
                               */
            
                                charExists(guess, word, game_Board, row_counter, lives);

                                for (int i = 0; i < guess.length(); i++)
                                {
                                    if (game_Board.at(row_counter).at(i).color == 'G')
                                    {
                                        greenExists = true;
                                        
                                        char letter = game_Board.at(row_counter).at(i).letter;
                                                                                
                                        if (greenChars.find(letter) == -1 && word.find(greenChars.find(letter)) == guess.find(greenChars.find(letter)))
                                        {
                                            // back here
                                            greenChars += letter;
                                            // cout << "316 -- Letter is: " << letter << endl;
                                            // cout << "----- Green chars IS:  " << greenChars << endl;
                                        }
                                    }
                                }

                                
                                // cout << "GreenChars: " << greenChars << " are in " << guess << ": " << checkChars(greenChars, guess) << endl;
                                if ( !checkChars(greenChars, guess, word) && (lives-copyLives) != 0 && word.length() > 1)
                                {
                                    cout << "You did not use the green letter in your word!" << endl;
                                    // cout << "Green_Chars: " << greenChars << " Guessed_Words: " << guessedWords << endl;
                                    greenChars = "";
                                }
                                else
                                {
                                    printBoard(word, game_Board, lives);
                                    row_counter++;
                                    // cout << "Value of row_counter: " << row_counter << endl;
                                    copyLives--;
                                }
                                
                            }
                        }
                        else
                        {
                            cout << "You've already tried this word!" << endl;
                        }
                    }
                }
            }
            else if (copyLives == 0)
            {
                cout << "You lose!" << endl;
                continueGame = false;
            }
        }
    }

    return 0;
}