#include <iostream>
#include <string>
#include <fstream>
#include <limits>

#include "DynStackHW4.h"


using namespace std;



void create_stack(string s, int &line_number, DynStack &stack, bool &error_found, bool &error_closing)
{    

    char dum, first, second;
    int popped; 
    int first_line, second_line;
    
    for (unsigned int a = 0; a != s.length();)
    {
        char ch = s.at(a);
        // {
        if (ch == '{') 
        {
            cout << "Found the opening symbol " << ch << " at line " << line_number << endl;
            stack.push(ch, line_number);
        }

        // }
        else if (ch == '}') // 1st closing symbol
        {
            stack.push(ch, line_number);
            if (!stack.isEmpty())
            {
                stack.pop(first, first_line);

                if (!stack.isEmpty())
                {    
                    stack.pop(second, second_line); // Error here, attempted to pop from an empty stack.

                    if (first == ch && second == '{')
                    {
                        cout << "Found the closing symbol " << first << " at line " << first_line;
                        cout << " which closes the opening symbol " << second << " at line " << second_line << endl;
                    }

                    else
                    {
                        cout << "ERROR!!! Found the closing symbol " << first << " at line " << first_line << " but the last unclosed opening symbol is " << second << " at line " << second_line << endl;
                        error_found = true;
                        a = s.length()-1;
                    }
                }
                else
                {
                    cout << "ERROR!!! Found the closing symbol " << first <<" but there are no unclosed opening symbols!" << endl;
                    error_closing = true;
                }
            }
        }

        // [
        else if (ch == '[')
        {
            cout << "Found the opening symbol " << ch << " at line " << line_number << endl;
            stack.push(ch, line_number);

        }
        
        // ]
        else if (ch == ']') // 2nd closing symbol
        {
            // cout << "Found the closing symbol " << ch << " at line " << line_number << endl;
            stack.push(ch, line_number);

            if (!stack.isEmpty())
            {
                stack.pop(first, first_line);

                if (!stack.isEmpty())
                {    
                    stack.pop(second, second_line); // Error here, attempted to pop from an empty stack.

                    if (first == ch && second == '[')
                    {
                        cout << "Found the closing symbol " << first << " at line " << first_line;
                        cout << " which closes the opening symbol " << second << " at line " << second_line << endl;
                    }

                    else
                    {
                        cout << "ERROR!!! Found the closing symbol " << first << " at line " << first_line << " but the last unclosed opening symbol is " << second << " at line " << second_line << endl;
                        error_found = true;
                        a = s.length()-1;
                    }
                }
                else
                {
                    cout << "ERROR!!! Found the closing symbol " << first <<" but there are no unclosed opening symbols!" << endl;
                    error_closing = true;
                }
            }
        }
        

        // (
        else if (ch == '(')
        {
            cout << "Found the opening symbol " << ch << " at line " << line_number << endl;
            
            stack.push(ch, line_number);

        }

        // )
        else if (ch == ')') // 3rd closing symbol
        {
            // Check if the last opening matches with the current char.
            stack.push(ch, line_number);

            if (!stack.isEmpty())
            {
                stack.pop(first, first_line);

                if (!stack.isEmpty())
                {    
                    stack.pop(second, second_line); // Error here, attempted to pop from an empty stack. FIXED

                    if (first == ch && second == '(')
                    {
                        cout << "Found the closing symbol " << first << " at line " << first_line;
                        cout << " which closes the opening symbol " << second << " at line " << second_line << endl;
                    }

                    else
                    {
                        cout << "ERROR!!! Found the closing symbol " << first << " at line " << first_line << " but the last unclosed opening symbol is " << second << " at line " << second_line << endl;
                        error_found = true;
                        a = s.length()-1;
                    }
                }
                else
                {
                    cout << "ERROR!!! Found the closing symbol " << first <<" but there are no unclosed opening symbols!" << endl;
                    error_closing = true;
                }
            }
        }
    a++;
    }
    line_number++;
}


int main()
{
    ifstream myfile;
    string fileName;

	do
    {
        cout << "Please enter the file name: ";
        cin >> fileName;
        myfile.open(fileName);
        if (myfile.fail())
        {
            cout << "File not found.\n";
        }
    } while (myfile.fail());
	cin.ignore(numeric_limits<streamsize>::max(),'\n'); 
    
    /* 
        Begin program by successfully opening destined file.
            -Create a stack
    */

    DynStack stack;

    string line, s;

    int line_number = 1;
    bool error_found = false, error_closing = false;


    while (getline(myfile, line) && !error_found && !error_closing)
    {  
        s = line;
        create_stack(s, line_number, stack, error_found, error_closing);
    }
    

    /* 
        After successfully reading the whole file and displaying related messages,
        check if stack is empty. 

            -If stack is empty, it means that all opening brackets have a matching closing
            bracket, no further error should be displayed.
    */
    if (stack.isEmpty()) 
    {
        if (!error_found && !error_closing)
        {
            cout << "File processed successfully. No errors were found." << endl;
        }
    }

    /*
        If stack is not empty
            -Then display an error message and symbol(s) with line number(s) on newline(s).
    */
    else if (!stack.isEmpty() && !error_found)
    {
        cout << "ERROR!!! The following opening symbols were not closed:" << endl;
        
        int line_Number_left_open; 
        char bracket_left_open;

        while (!stack.isEmpty())
        {
            stack.pop(bracket_left_open ,line_Number_left_open);
            cout << "   Symbol " << bracket_left_open << " at line " << line_Number_left_open << endl;
        }

    }

    myfile.close();
    system("pause");
	return 0;
}