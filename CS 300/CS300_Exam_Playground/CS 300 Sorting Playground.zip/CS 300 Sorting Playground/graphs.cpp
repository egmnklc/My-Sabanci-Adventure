/**
 * @file graphs.cpp
 * @author Egemen Kilic (egemenkilic@sabanciuniv.edu)
 * @brief 
 * @version 0.1
 * @date 2022-12-23
 * 
 * @copyright Copyright (c) 2022
 * 
 * ! Graph (see 2022-12-23-21-46-10.png)
 * * Directed Graph: Have pair of ordered vertices (u, v), there's an arrow
 * * Un-Directed Graph: There isn't an arrow between vertices
 * * - Graph applications:
 * *    - Social Networks, City-Road Network, Precedence Constraints
 * * - Weighted oldugu zaman edgelerin uzerinde sayi yaziyor, adjacency matrixte de 1 yerine o 
 * * sayiyi yaziyorsun.
 * 
 * 
 * ! Graph Representations
 * * Adjacency Matrix: (see 2022-12-23-21-49-58.png)
 * * - 2d matrix of size VxV , V is # of nodes, Aij = 1 means i and j are connected
 * * For pros, see 2022-12-23-21-51-59.png
 * * For cons, see 2022-12-23-21-52-22.png  
 * !        IT DOESN'T HAVE TO BE A SYMMETRIC MATRIX
 * * Adjacency List (see 2022-12-23-21-54-14.png): 
 * * - An array of linked lists is used. Size of the array is equal to the # of Vertices
 * * and each entry of array corresponds to a linked list of vertices adjacent to this index. 
 * * For pros AND cons, see 2022-12-23-21-54-44.png
 * * - It consumes less space because we store only the connected vertices. 
 * * - Max space is required when each Vertice is connected to all other vertices.
 * *
 * *
 */